# Samsung FRP Bypass

A blog article available in english and in french explaining how the scripts work can be found [here](https://blog-cyber.riskeco.com/en/analysis-of-samsung-frp-bypass/)  

## How to use

- Make sure you have all the dependencies listed in `requirements.txt` installed
  - Install them using `pip install -r requirements.txt`
- You can simply plug the samsung over USB and run `python main.py`
